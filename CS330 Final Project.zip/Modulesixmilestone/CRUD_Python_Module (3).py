# CRUD_Python_Module.py
# Simple MongoDB CRUD class for Project One and Module Five

from pymongo import MongoClient

class AnimalShelterCRUD:
    def __init__(self, username="aacuser", password="kuromi", host="localhost", dbname="aac"):
        """
        Initialize MongoDB connection with authentication
        """
        # Build MongoDB connection string
        self.client = MongoClient(
    f"mongodb://{username}:{password}@{host}:27017/?authSource=aac"
)
        # Select database
        self.db = self.client[dbname]
        # Select collection (you can change this to any collection name)
        self.collection = self.db["outcomes"]

    def create(self, document):
        """
        Insert a new document
        Returns True if inserted successfully
        """
        try:
            self.collection.insert_one(document)
            return True
        except Exception as e:
            print(f"Create failed: {e}")
            return False

    def read(self, query):
        """
        Read documents matching query
        Returns a list of results
        """
        try:
            results = self.collection.find(query)
            return list(results)
        except Exception as e:
            print(f"Read failed: {e}")
            return []

    def update(self, query, updates):
        """
        Update documents matching query
        Returns number of documents modified
        """
        try:
            result = self.collection.update_many(query, {"$set": updates})
            return result.modified_count
        except Exception as e:
            print(f"Update failed: {e}")
            return 0

    def delete(self, query):
        """
        Delete documents matching query
        Returns number of documents deleted
        """
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"Delete failed: {e}")
            return 0
